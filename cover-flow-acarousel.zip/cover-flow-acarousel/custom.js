$(function () {
	var len = $("#carousel").children().length;
	var acarousel = $("#carousel").acarousel({
		moveStep: function (elem, index, pos_index, t) {
			if (pos_index >= 3 && pos_index < len - 3 || pos_index == len - 3 && t == 0) {
				elem.hide();
			}
		}
	});

	changeActive();

	$("#carousel li a").click(function() {
		var move = acarousel.moveByElem($(this).parent());
		changeActive(move);
		return false;
	});

	$("#move_back").click(function () {
		var move = acarousel.move(1);
		changeActive(move);
		return false;
	});

	$("#move_next").click(function () {
		var move = acarousel.move(-1);
		changeActive(move);
		return false;
	});

	$(".move").click(function () {

		var pos = acarousel.getPos();
		pos = pos.index % 5 + pos.point;
		pos = parseInt($(".move").index(this)) - pos;

		var diff1 = Math.abs(pos) % 5 * (pos < 0 ? 1 : -1);
		var diff2 = (10 - (Math.abs(pos) + 5)) % 5 * (pos < 0 ? -1 : 1);

		move = acarousel.move(Math.abs(diff1) < Math.abs(diff2) ? diff1 : diff2);
		changeActive(move);
		return false;
	});

	function changeActive(move) {
		var index = acarousel.getPos(move).index % 5;
		$(".move").removeClass("active").eq(index).addClass("active");
	}

	$(window).resize(function () {
		var parent = $("#carousel_container");
		var self = $("#carousel");
		self.css({
			left: parent.width() / 2 - self.width() / 2
			, top: parent.height() / 2 - self.height() / 2
		});
	}).trigger("resize");

});