https://kozok-dev.github.io/acarousel/

MIT License<br>
※aslider teamは別名義
